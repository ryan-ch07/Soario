This is our TSA State Project app. There are multiple pages

Gen Disease: Our app uses a dataset with up to 37 diseases and 132 symptoms. After preprocessing we integrated 4 ML models, Naive Boyes, Random Forest, KNN, and SVM. The accuracy is 94%. The purpose is to allow patients with rare or unknown diseases to receive a diagnosis and then be able to receive information on their condition. 

Diabetes: Our application uses data from Kaggle to diagnose a patient with diabetes based on their symptoms with the Random Forest ML model. Currently, we have a 94% accuracy percentage. 

Stroke: Our application diagnoses a patient's risk of stroke as a percentage chance and also includes a confidence score. 

Hospital Tracker: Our app uses a Google Maps API to locate all nearby hospitals from a user.

Index: Contains information about all diseases included within our databases letting users quickly find info on their condition. 

Welcome to KGK. 
